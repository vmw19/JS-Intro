function loadData() {
    console.log("Getting data from sever");
}

function init() {
    console.log("Page loaded");

    loadData();
}

function sayHello10times() {
    for (var i = 1; i <= 10; i++) {
        console.log("Hello");
    }
}

function printSomeNumbers1() {
    for (let i = 0; i < 21; i++) {
        console.log(i);

    }
}

function printSomeNumbers2() {
    for (let i = 0; i < 21; i++) {
        if (i != 7) {
            console.log(i);
        }
    }
}
//this did not work for me //my error was the syntax for the not equals operator (Tutoring)
function printSomeNumbers3() {
    for (let i = 0; i < 21; i++) {
        if (i != 7 && i != 13) {
            console.log(i);
        }
    }
}
let ages = [12, 43, 12, 87, 34, 67, 40, 24, 89, 38, 623, 20, 5, 24, 13, 84, 22, 55];
sumAll(ages); //print the sum of all the numbers

function sumAll(list) {
    console.log("---SUM ALL---");

    let total = 0;
    for (let i = 0; i < list.length; i++) {
        let num = list[i];
        //total = total + num;
        total += num;
    }
    console.log("Result", total);
}


function findOldest(list) {
    let solution = list[0];

    for (let i = 0; i < list.length; i++) {
        let num = list[i];
        if (num > solution) {
            solution = num;
        }
    }
    console.log("Oldest", solution);
}

function countLowerThan(pivot, list) {
    let count = 0;
    for (let i = 0; i < list.length; i++) {
        let num = list[i];
        if (num < pivot) {
            count += 1;
        }
    }
    console.log("There are", count, "nums lower than", pivot);
}

//exercise 
sayHello10times();
//Print Numbers from 0 to 20
printSomeNumbers3();
//print numbers except 7
//print numbers except 7 and 13 TUTORING
//sum of all numbers DID NOT WORk
findOldest(ages); //print the oldest person on the list
countLowerThan(25, ages) //print the count

window.onload = init;